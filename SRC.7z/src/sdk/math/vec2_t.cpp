#include "vec2_t.hpp"

vec2_t::vec2_t()
{
	this->x = 0.f;
	this->y = 0.f;
}

vec2_t::vec2_t(float x, float y)
{
	this->x = x;
	this->y = y;
}

vec2_t::~vec2_t()
{

}

vec2_t vec2_t::operator+(vec2_t& other)
{
	return vec2_t(x + other.x, y + other.y);
}
