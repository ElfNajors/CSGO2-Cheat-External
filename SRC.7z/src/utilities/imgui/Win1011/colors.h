#pragma once

#include "../atgui.h"

namespace Colors
{
	extern bool showWindow;

	extern void RenderWindow();
}