#pragma once

#include "../atgui.h"

namespace Misc
{
	void RenderTab();
}