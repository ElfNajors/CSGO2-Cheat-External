#pragma once

#include "../atgui.h"

namespace HvH
{
	void RenderTab();
}